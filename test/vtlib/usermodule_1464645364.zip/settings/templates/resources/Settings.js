/* * *******************************************************************************
 * The content of this file is subject to the VTE Custom User Login Page ("License");
 * You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is VTExperts.com
 * Portions created by VTExperts.com. are Copyright(C)VTExperts.com.
 * All Rights Reserved.
 * ****************************************************************************** */

 var Settings_UserLogin_Js = {


    registerEditBtn : function() {
        var thisInstance = this;
        jQuery('.editButton').on('click', function(event){
            event.preventDefault();
            var records = thisInstance.getRecordsSelected();
            if(records.length==0){
                alert(app.vtranslate('JS_PLEASE_SELECT_ONE_RECORD'));
            }else{
                window.location.assign('index.php?module=UserLogin&view=Edit&parent=Settings&record='+records[0]);
            }
        });
    },

     registerDeleteBtn : function() {
         var thisInstance = this;
         jQuery('.deleteButton').on('click', function(event){
             event.preventDefault();
             var records = thisInstance.getRecordsSelected();
             if(records.length==0){
                 alert(app.vtranslate('JS_PLEASE_SELECT_ONE_RECORD'));
             }else{
                 var params = {};
                 params['module'] = 'UserLogin';
                 params['parent'] = 'Settings';
                 params['action'] = 'DeleteAjax';
                 params['record'] = records;
                 var message = app.vtranslate('LBL_DELETE_CONFIRMATION');
                 Vtiger_Helper_Js.showConfirmationBox({'message' : message}).then(function(data) {
                         var aDeferred = jQuery.Deferred();
                         var progressIndicatorElement = jQuery.progressIndicator({
                             'position' : 'html',
                             'blockInfo' : {
                                 'enabled' : true
                             }
                         });
                         AppConnector.request(params).then(
                             function(data) {
                                 progressIndicatorElement.progressIndicator({
                                     'mode' : 'hide'
                                 });
                                 aDeferred.resolve(data);
                                 window.location.reload();
                             },
                             function(error,err){
                                 progressIndicatorElement.progressIndicator({
                                     'mode' : 'hide'
                                 });
                                 aDeferred.reject(error,err);
                             }
                         );
                         return aDeferred.promise();
                     },
                     function(error, err){
                     }
                 );
             }
         });
     },

     registerGenerateBtn : function() {
         var thisInstance = this;
         jQuery('.generateButton').on('click', function(event){
             event.preventDefault();
             var records = thisInstance.getRecordsSelected();
             if(records.length==0){
                alert(app.vtranslate('JS_PLEASE_SELECT_ONE_RECORD'));
             }else{
                 var url = jQuery(this).data('url')+'&record='+records[0];
                 var message = app.vtranslate('LBL_GENERATE_CONFIRMATION');
                 Vtiger_Helper_Js.showConfirmationBox({'message' : message}).then(function(data) {
                         var aDeferred = jQuery.Deferred();
                         var progressIndicatorElement = jQuery.progressIndicator({
                             'position' : 'html',
                             'blockInfo' : {
                                 'enabled' : true
                             }
                         });
                         AppConnector.request(url).then(
                             function(data) {
                                 progressIndicatorElement.progressIndicator({
                                     'mode' : 'hide'
                                 });
                                 if(data.result === true){
                                     var params = {
                                         title: app.vtranslate('GENERATE_TITLE'),
                                         text: app.vtranslate('GENERATE_SUCCESS'),
                                         width: '35%',
                                         type: 'info'
                                     };
                                 }else{
                                     var params = {
                                         title: app.vtranslate('GENERATE_TITLE'),
                                         text: app.vtranslate('GENERATE_FAIL'),
                                         width: '35%',
                                         type: 'error'
                                     };
                                 }
                                 Vtiger_Helper_Js.showPnotify(params);
                                 aDeferred.resolve(data);
                             },
                             function(error,err){
                                 progressIndicatorElement.progressIndicator({
                                     'mode' : 'hide'
                                 });
                                 aDeferred.reject(error,err);
                             }
                         );
                         return aDeferred.promise();
                     },
                     function(error, err){
                     }
                 );
             }

         });
     },

     registerRestoreBtn : function() {
         var thisInstance = this;
         jQuery('.restoreButton').on('click', function(event){
             event.preventDefault();
             var url = jQuery(this).data('url');
             var message = app.vtranslate('LBL_RESTORE_CONFIRMATION');
             Vtiger_Helper_Js.showConfirmationBox({'message' : message}).then(function(data) {
                     var aDeferred = jQuery.Deferred();
                     var progressIndicatorElement = jQuery.progressIndicator({
                         'position' : 'html',
                         'blockInfo' : {
                             'enabled' : true
                         }
                     });
                     AppConnector.request(url).then(
                         function(data) {
                             progressIndicatorElement.progressIndicator({
                                 'mode' : 'hide'
                             });
                             if(data.result === true){
                                 var params = {
                                     title: app.vtranslate('RESTORE_TITLE'),
                                     text: app.vtranslate('RESTORE_SUCCESS'),
                                     width: '35%',
                                     type: 'info'
                                 };
                             }else{
                                 var params = {
                                     title: app.vtranslate('RESTORE_TITLE'),
                                     text: app.vtranslate('RESTORE_FAIL'),
                                     width: '35%',
                                     type: 'error'
                                 };
                             }
                             Vtiger_Helper_Js.showPnotify(params);
                             aDeferred.resolve(data);
                         },
                         function(error,err){
                             progressIndicatorElement.progressIndicator({
                                 'mode' : 'hide'
                             });
                             aDeferred.reject(error,err);
                         }
                     );
                     return aDeferred.promise();
                 },
                 function(error, err){
                 }
             );
         });
     },

    getRecordsSelected : function(){
        var records = [];
        jQuery('.vte-user-login .listViewEntryValue input[type=checkbox]:checked').each(function() {
            records .push(jQuery(this).val());
        });
        return records;
    },

     registerImageSettingBtn : function() {
         var thisInstance = this;
         jQuery('.imgSetting').on('click', function(event){
             event.preventDefault();
             var url = jQuery(this).data('url');
             app.showModalWindow(null, url, function(){
                 thisInstance.registerSaveImgSetting();
             });
         });
     },

     registerSaveImgSetting : function() {
         var form = jQuery('#vte-img-setting');
         form.submit(function(e) {
             jQuery.ajax({
                 type: "POST",
                 url: 'index.php',
                 data: form.serialize(), // serializes the form's elements.
                 success: function(data)
                 {
                     app.hideModalWindow();
                 }
             });
             e.preventDefault(); // avoid to execute the actual submit of the form.
         });
     },

    registerEvents : function() {
        this.registerEditBtn();
        this.registerDeleteBtn();
        this.registerGenerateBtn();
        this.registerRestoreBtn();
        this.registerImageSettingBtn();
    }

}

jQuery(document).ready(function(){
    Settings_UserLogin_Js.registerEvents();
});