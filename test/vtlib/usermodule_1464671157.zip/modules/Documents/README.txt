<h3>Docs++ 630</h3>
<p>Hello vTigers and vTigresses,
We have a release of a module extension module for vtiger 6.0 !!

Presenting, Docs ++ new version, with

* Drag and drop of documents
* Scan of documents ( WebTwain license required )
* Associations with entity modules
* Nested/Tree UI for Folder management
* Detail View Widget in associated modules
* Settings
* Module Manager installable, works with all Vtiger 6 versions


Please read the <a href="http://www.vtigress.com/license" target="_blank">End User License Agreement</a> and <a href="http://www.vtigress.com" target="_blank">documentation</a> before installing. 
Enjoy

S.T.Prasad
27 June 2015
Hyderabad, 
Telangana, India
</p>
<h4>Scripts changed</h4>
models/Module.php
models/ListView.php

<h4>Scripts added</h4>
All the rest of the scripts