<?php
/* +***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 * *********************************************************************************** */

class Documents_ListFolders_View extends Vtiger_PopupAjax_View {

    protected $noRecords = false;

    public function __construct() {
//        $this->exposeMethod('Contacts');
//        $this->exposeMethod('Calendar');
    }

    function process(Vtiger_Request $request) {
        switch ($request->get('operation')) {
//            case "sync" : $this->renderSyncUI($request);
//                break;
//            case "removeSync" : if($request->validateWriteAccess()){
//                                    $this->deleteSync($request);
//                                }
//                break;
            default: $this->renderWidgetUI($request);
                break;
        }
    }

    function renderWidgetUI(Vtiger_Request $request) {
        $sourceModule = $request->get('sourcemodule');
        $viewer = $this->getViewer($request);
        $viewer->assign('MODULE_NAME', $request->getModule());
        $viewer->assign('FIRSTTIME', $firstime);
        $viewer->assign('STATE', 'home');
        $viewer->assign('SOURCEMODULE', $request->get('sourcemodule'));
        //$viewer->assign('SCRIPTS',$this->getHeaderScripts($request));
		/*code added by SL on 29th July for tree of storage folder ---start 
		$jsontree = $this->generateJSON($request);
		if(json_encode($jsontree)!=''){
			
			$fp = fopen('modules/Documents/plugins/ajax-tree-local.json', 'w');
			fwrite($fp, json_encode($jsontree));
			fclose($fp);
		}*/
		//manasa commented the above code on jan 12 2015
		$folders = $this->getVirtualTreeDocs();
		$folderdetails = $this->getVirtualTreeDocumentsDetails();
		//print_r($folderdetails);
		$viewer->assign('FOLDERS',$folders);
		$viewer->assign('FOLDERINFO',$folderdetails);
		//manasa code ended here on jan 12 2015
		//code added by SL on 29th July for tree of storage folder ---end
		$viewer->view('ListFolders.tpl', $request->getModule());
    }


	public function getHeaderCss(Vtiger_Request $request) {
		$parentHeaderCssScriptInstances = parent::getHeaderCss($request);

		$headerCss = array(
			"~/layouts/vlayouts/modules/resources/Documents/tree.css"
		);
		$cssScripts = $this->checkAndConvertCssStyles($headerCss);
		$headerCssScriptInstances = array_merge($parentHeaderCssScriptInstances , $cssScripts);
		return $headerCssScriptInstances;
	}
    
    public function validateRequest(Vtiger_Request $request) {
        //don't do validation because there is a redirection from google
    }
			
	//code added by SL on 29th July for tree of storage folder ---start 
	public function generateJSON(Vtiger_Request $request) {
		$moduleName = $request->getModule();
		 
		 $rootarray = array();
		$subarray;
			$mainarry = glob('storage/*',GLOB_ONLYDIR);
		 for($i=0;$i<sizeof($mainarry);$i++){
			 $pos =intval(strrpos($mainarry[$i],'/'));
			 $rootdir= substr($mainarry[$i],$pos+1);
			 $totalarray=array();
			if ($dh = opendir($mainarry[$i])) {
				while (($file=readdir($dh)) !== false) {
					 if ($file != "." && $file != ".." && $file != "Thumb.db" && $file !='.htaccess')
					{
						
						if(is_file($mainarry[$i]."/".$file))
						{
							
						$totalarray[] =array('key'=>$i,'title'=>$file);
						}
						elseif(is_dir($mainarry[$i]."/".$file))
						{
						 
						//
						$first=$this->childjson($i+1,$mainarry[$i]."/".$file);
						array_push($totalarray,array('key'=>$i,'title'=>$file,"folder"=> true,'children'=>$first));


						}
					}
				}
			}
			array_push($rootarray,array('key'=>$i,'title'=>$rootdir,"folder"=> true,'children'=>$totalarray));
		}
	 return $rootarray;
	}
	public function childjson($itr,$paths){
	 
		$stotalarray=array();
		  $subarray = glob($paths.'*',GLOB_ONLYDIR);
			 for($j=0;$j<sizeof($subarray);$j++){
				if ($dh = opendir($subarray[$j])) {
					while (($file=readdir($dh)) !== false) {
						 if ($file != "." && $file != ".." && $file != "Thumb.db" && $file !='.htaccess')
						{
							
							if(is_file($subarray[$j]."/".$file))
							{
								
							$stotalarray[] =array('key'=>$itr.'_'.$j,'title'=>$file);
							}
							elseif(is_dir($subarray[$j]."/".$file))
							{
							 $test=$this->childjson($itr.'_'.$j,$subarray[$j]."/".$file);
							array_push($stotalarray,array('key'=>$itr.'_'.$j,'title'=>$file,"folder"=> true,'children'=>$test));
							


							}
						}
					}
				}
			}
	return $stotalarray;
	}
//code added by SL on 29th July for tree of storage folder ---end
	 //manasa code added here on jan 12 2015
	public function getVirtualTreeDocs(){
		$db = PearDatabase::getInstance();
		$floderquery = "SELECT folderid, foldername FROM vtiger_attachmentsfolder order by foldername ASC";
		$fres = $db->query($floderquery);
		$numRows = $db->num_rows($fres);
		$folders = array();
		for ($i = 0; $i < $numRows; $i++) {
			$folderid = $db->query_result($fres, $i, "folderid");
			$foldername = $db->query_result($fres, $i, "foldername");
			$folders[$folderid]= $foldername;
		}
		return $folders;

	}
	public function getVirtualTreeDocumentsDetails(){
		$db = PearDatabase::getInstance();
		$floderquery = "SELECT snrel.attachmentsid,notesid,folderid,filename FROM vtiger_seattachmentsrel as snrel left join vtiger_crmentity  on snrel.crmid = vtiger_crmentity.crmid left join vtiger_notes on vtiger_notes.notesid=snrel.crmid where vtiger_crmentity.deleted=0 and filename != '' order by folderid ASC";
		$fres = $db->query($floderquery);
		$numRows = $db->num_rows($fres);
		$folderdetails = array();
		for ($i = 0; $i < $numRows; $i++) {
			$folderid = $db->query_result($fres, $i, "folderid");
			$notesid = $db->query_result($fres, $i, "notesid");
			$attachmentsid = $db->query_result($fres, $i, "attachmentsid");
			$filename = $db->query_result($fres, $i, "filename");
			$link = '<a title="Download File" href="index.php?module=Documents&action=DownloadFile&record='.$notesid.'&fileid='.$attachmentsid.'">'.$filename.'</a>';
			$folderdetails[$folderid][]=array($notesid,$attachmentsid,$filename,$link);
		}
		return $folderdetails;
	}
	//manasa code ended here on jan 12 2015
}

