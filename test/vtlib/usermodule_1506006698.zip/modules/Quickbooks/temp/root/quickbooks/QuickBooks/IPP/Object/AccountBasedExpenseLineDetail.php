<?php

QuickBooks_Loader::load('/QuickBooks/IPP/Object.php');

class QuickBooks_IPP_Object_AccountBasedExpenseLineDetail extends QuickBooks_IPP_Object
{
	
}
