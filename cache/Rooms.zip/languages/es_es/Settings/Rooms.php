<?php
/* * *******************************************************************************
 * The content of this file is subject to the VTE List View Colors ("License");
 * You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is VTExperts.com
 * Portions created by VTExperts.com. are Copyright(C)VTExperts.com.
 * All Rights Reserved.
 * ****************************************************************************** */

$languageStrings = array(
    // Basic Strings
    'MODULE_MANAGEMENT' => 'Module Management',
    'ENABLE_LINK_TO_RECORD' => 'Module Linked',
    'SETTING_GUID' => 'Please select modules you would like to link chats to',

);

$jsLanguageStrings = array(
    'LBL_DELETE_CONFIRMATION' => 'Are you sure?',
);