<?php
/* ********************************************************************************
 * The content of this file is subject to the Collaboration ("License");
 * You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is VTExperts.com
 * Portions created by VTExperts.com. are Copyright(C) VTExperts.com.
 * All Rights Reserved.
 * ****************************************************************************** */
$languageStrings = array(
    'LBL_MODULE_MANAGER' => 'Module Management',
    'LBL_FOLDERS_AND_FILES' => 'Folder(s) & File(s)',
    'LBL_QUERIES_STATEMENT' => 'Queries',
    'LBL_UNINSTALL' => 'Uninstall',

);
$jsLanguageStrings = array(
    
);
