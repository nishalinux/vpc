<?php	
class Quickbooks {
 	
 	/**
	* Invoked when special actions are performed on the module.
	* @param String Module name
	* @param String Event Type
	*/
 	function vtlib_handler($moduleName, $eventType) {
 					
		require_once('include/utils/utils.php');
		require_once('modules/com_vtiger_workflow/VTEntityMethodManager.inc');		
		global $adb;
 		
 		if($eventType == 'module.postinstall') {			
			// TODO Handle actions when this module is disabled.
			
			//copy the file from temp to root 
			$this->copy_r( 'modules/Quickbooks/temp/root/cron/modules/', 'cron/modules/' );
			$this->copy_r( 'modules/Quickbooks/temp/root/quickbooks/', 'quickbooks/' );			
			
			//Inserting Querys for Qb Field Settings
			$query = $this->getQuerys();
			$adb->query($query);
			//End
			
			/*-- Vendors Workflow -- 		
			$emm = new VTEntityMethodManager($adb);                   
			$emm->addEntityMethod("Vendors", "Save Vendors In QuickBooks", "modules/Quickbooks/Workflows/SaveVendorsInQuickBooks.php", "createVendorsInQuickbooks");	 
			
			/*-- Products Workflow -- 	
			$emm->addEntityMethod("Products", "Save Products In QuickBooks", "modules/Quickbooks/Workflows/SaveProductsInQuickBooks.php", "createProductsInQuickbooks");
			
			/*-- Services Workflow -- 		 
			$emm->addEntityMethod("Services", "Save Services In QuickBooks", "modules/Quickbooks/Workflows/SaveServicesInQuickBooks.php", "createServicesInQuickbooks"); 
			
			/*-- Invoice Workflow -- 
			$emm->addEntityMethod("Invoice", "Save Invoice In QuickBooks", "modules/Quickbooks/Workflows/SaveInvoiceInQuickBooks.php", "createInvoiceInQuickbooks"); 
			
			/*-- Contacts Workflow -- 		
			$emm->addEntityMethod("Contacts", "Save Contact In QuickBooks", "SaveContactInQuickBooks.php", "createContactInQuickbooks");
			//end Workflow declaration */ 
			
			
		} else if($eventType == 'module.disabled') {
			// TODO Handle actions when this module is disabled.
		} else if($eventType == 'module.enabled') {
			// TODO Handle actions when this module is enabled.
		} else if($eventType == 'module.preuninstall') {
			// TODO Handle actions when this module is about to be deleted.
		} else if($eventType == 'module.preupdate') {
			// TODO Handle actions before this module is updated.
		} else if($eventType == 'module.postupdate') {
			// TODO Handle actions after this module is updated.
			
			//copy the file from temp to root 
			$this->copy_r( 'modules/Quickbooks/temp/root/cron/modules/', 'cron/modules/' );
			$this->copy_r( 'modules/Quickbooks/temp/root/quickbooks/', 'quickbooks/' );
			
			
			//Inserting Querys for Qb Field Settings
			$query = $this->getQuerys();
			$adb->query($query);
			//End
			
		}
 	}
	
	
	public function getQuerys(){
		$return   "	INSERT INTO `quickbooks_fields` (`id`, `qb_field_name`, `module`, `vtiger_field`, `flag`) VALUES
							(1, 'First Name', 'Contacts', 'First Name', 1),
							(2, 'Last Name', 'Contacts', 'Last Name', 1),
							(3, 'Company Name', 'Contacts', 'Account Name', 1),
							(4, 'Phone', 'Contacts', 'Home Phone', 1),
							(5, 'Mobile', 'Contacts', 'Mobile', 1),
							(6, 'Other Phone', 'Contacts', 'Other Phone', 1),
							(7, 'Fax', 'Contacts', 'Fax', 1),
							(8, 'Email', 'Contacts', 'Email', 1),
							(9, 'Street', 'Contacts', 'Mailing Street', 1),
							(10, 'City', 'Contacts', 'Mailing City', 1),
							(11, 'State', 'Contacts', 'Mailing State', 1),
							(12, 'Zip', 'Contacts', 'Mailing Zip', 1),
							(13, 'Country', 'Contacts', 'Mailing Country', 1),
							(14, 'Notes', 'Contacts', 'Description', 1),
							(15, 'Customer Name', 'Invoice', 'Contact Name', 1),
							(16, 'Invoice No', 'Invoice', 'Invoice No', 1),
							(17, 'Invoice Date', 'Invoice', 'Invoice Date', 1),
							(18, 'Invoice Due Date', 'Invoice', 'Due Date', 1),
							(19, 'Bill Address', 'Invoice', 'Billing Address', 1),
							(20, 'Ship Address', 'Invoice', 'Shipping Address', 1),
							(21, 'Products', 'Invoice', 'Item Name', 1),
							(22, 'Quantity', 'Invoice', 'Quantity', 1),
							(23, 'List Price', 'Invoice', 'List Price', 1),
							(24, 'Tax', 'Invoice', 'S&H Amount', 1),
							(25, 'Discount', 'Invoice', 'Discount Amount', 1),
							(26, 'Shipping', 'Invoice', 'Shipping Address', 1),
							(27, 'Shipping Address', 'Invoice', 'Shipping Address', 1),
							(28, 'Name', 'Products', 'Product Name', 1),
							(29, 'Price', 'Products', 'Usage Unit', 1),
							(30, 'Description', 'Products', 'Description', 1),
							(31, 'Name', 'Services', 'Service Name', 1),
							(32, 'Price', 'Services', 'Price', 1),
							(33, 'Description', 'Services', 'Description', 1),
							(34, 'Name', 'Vendors', 'Vendor Name', 1),
							(35, 'Email', 'Vendors', 'Email', 1),
							(36, 'Phone', 'Vendors', 'Phone', 1),
							(37, 'Website', 'Vendors', 'Website', 1),
							(38, 'Street', 'Vendors', 'Street', 1),
							(39, 'City', 'Vendors', 'City', 1),
							(40, 'State', 'Vendors', 'State', 1),
							(41, 'Zip', 'Vendors', 'Postal Code', 1),
							(42, 'Inventory Start Date', 'Services', 'Sales Start Date', 1),
							(43, 'Inventory Start Date', 'Products', 'Sales Start Date', 1),
							(44, 'Qty in Stock', 'Products', 'Qty In Stock', 1);";
	}
	
	
	function copy_r( $path, $dest ) {
        if( is_dir($path) ) {
            //@mkdir( $dest );
            @mkdir( $dest ,0777,true);
            $objects = scandir($path);
            if( sizeof($objects) > 0 ) {
                foreach( $objects as $file ) {
                    if( $file == "." || $file == ".." )
                        continue;
                    // go on
                    if( is_dir( $path.DIRECTORY_SEPARATOR.$file ) ) {
                        $this->copy_r( $path.DIRECTORY_SEPARATOR.$file, $dest.DIRECTORY_SEPARATOR.$file );
                    }
                    else {
						// TODO Must save existing script copies for rollback
						//$this->vtFileCopy($dest.DIRECTORY_SEPARATOR.$file);
                        $crslt = copy( $path.DIRECTORY_SEPARATOR.$file, $dest.DIRECTORY_SEPARATOR.$file );
						/*if ($crslt) {
							//echo "Copied ".$path.DIRECTORY_SEPARATOR.$file." to ".$dest.DIRECTORY_SEPARATOR.$file."<br>";
							$this->copiedFiles[] = "Copied ".$path.DIRECTORY_SEPARATOR.$file." to ".$dest.DIRECTORY_SEPARATOR.$file;
						}
						else {
							$this->failedCopies[] = "Could not copy ".$path.DIRECTORY_SEPARATOR.$file." to ".$dest.DIRECTORY_SEPARATOR.$file;
						}*/
                    }
                }
            }
           // return true;
        }
        elseif( is_file($path) ) {
			$crslt = copy($path, $dest);
			if ($crslt)
			{
				//echo "Copied ".$path.DIRECTORY_SEPARATOR.$file." to ".$dest.DIRECTORY_SEPARATOR.$file."<br>";
				//$this->copiedFiles[] = "Copied ".$path.DIRECTORY_SEPARATOR.$file." to ".$dest.DIRECTORY_SEPARATOR.$file;
			}
			else {
				//echo "<font color=red>Could not copy ".$path.DIRECTORY_SEPARATOR.$file." to ".$dest.DIRECTORY_SEPARATOR.$file."</font><br>";
				//$this->failedCopies[] = "Could not copy ".$path.DIRECTORY_SEPARATOR.$file." to ".$dest.DIRECTORY_SEPARATOR.$file;
			}
           // return $crslt;
        }
        else {
            //return false;
        }
    } 
}
?>
