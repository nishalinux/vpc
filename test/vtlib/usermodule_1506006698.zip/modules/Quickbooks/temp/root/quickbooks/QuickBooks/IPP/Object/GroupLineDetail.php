<?php

QuickBooks_Loader::load('/QuickBooks/IPP/Object.php');

class QuickBooks_IPP_Object_GroupLineDetail extends QuickBooks_IPP_Object
{
	
}
