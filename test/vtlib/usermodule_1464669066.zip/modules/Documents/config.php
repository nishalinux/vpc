<?php



// Settings saved on Feb 04 2016 08:44:00 by Oliver Z&ouml;llner Admin

$vtDocsSettings = array (
  'HelpDesk' => 
  array (
    '__vtrftk' => 'sid:cef71a4b678f0ceba804740b04f311b64d543b34,1454574140',
    'folderslist' => '32',
    'fileextensions' => 'Allowall',
    'xyz' => 
    array (
      0 => '.jpeg',
      1 => '.gif',
      2 => '.doc',
      3 => '.odt',
      4 => '.xls',
    ),
    'hdModulename' => 'HelpDesk',
  ),
  'Potentials' => 
  array (
    '__vtrftk' => 'sid:1ae83a6e2fac1f9da708392da513c78607d5d99e,1454573303',
    'folderslist' => '50',
    'fileextensions' => 'Exclude',
    'xyz' => 
    array (
      0 => '.png',
      1 => '.gif',
      2 => '.pdf',
      3 => '.doc',
      4 => '.xls',
    ),
    'hdModulename' => 'Potentials',
  ),
  'Contacts' => 
  array (
    '__vtrftk' => 'sid:3bbd9050efcec7e16ffcd4defa761de64e9835bd,1454573617',
    'folderslist' => '56',
    'fileextensions' => 'Include',
    'xyz' => 
    array (
      0 => '.jpeg',
      1 => '.png',
      2 => '.bmp',
      3 => '.pdf',
      4 => '.doc',
      5 => '.odt',
    ),
    'hdModulename' => 'Contacts',
  ),
  'Accounts' => 
  array (
    '__vtrftk' => 'sid:f0de34dafde2a401be89ba8a04ba6bc54e58c594,1454573792',
    'folderslist' => '1',
    'fileextensions' => 'Allowall',
    'xyz' => 
    array (
      0 => '.gif',
      1 => '.bmp',
      2 => '.pdf',
      3 => '.ppt',
      4 => '.doc',
      5 => '.odt',
      6 => '.xls',
    ),
    'hdModulename' => 'Accounts',
  ),
  'Leads' => 
  array (
    '__vtrftk' => 'sid:746e9a1d9fefd4503af1f1d3d4994a37745eccf2,1454574064',
    'folderslist' => '48',
    'fileextensions' => 'Allowall',
    'xyz' => 
    array (
      0 => '.pdf',
      1 => '.doc',
    ),
    'hdModulename' => 'Leads',
  ),
  'Faq' => 
  array (
    '__vtrftk' => 'sid:4bb9e0a1bcc626287728d409e35fa27331a8f326,1454566901',
    'folderslist' => '7',
    'fileextensions' => 'Exclude',
    'xyz' => 
    array (
      0 => '.pdf',
      1 => '.doc',
    ),
    'hdModulename' => 'Faq',
  ),
  'Vendors' => 
  array (
    '__vtrftk' => 'sid:2bce50a8d40ee01c8dd9fd9051b2d082f6dbbe86,1454574216',
    'folderslist' => '45',
    'fileextensions' => 'Include',
    'xyz' => 
    array (
      0 => '.png',
      1 => '.pdf',
    ),
    'hdModulename' => 'Vendors',
  ),
  'Products' => 
  array (
    '__vtrftk' => 'sid:a544a993bbcc104380dc161496010d80a3e91068,1454575416',
    'folderslist' => '74',
    'fileextensions' => 'Allowall',
    'hdModulename' => 'Products',
  ),
);
?>